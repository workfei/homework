<template>
  <div>
    <add-books @add='getAddbook' @update='updatebook' :books='books'></add-books>
    <count :counts='counts'></count>
    <my-books @delete='deletebook' :books='books'></my-books>
  </div>
</template>

<style scoped>
.book {
  width: 80%;
  height: 30px;
  font-size: 24px;
  line-height: 30px;
  background-color: orange
}

table {
  text-align: center;
}

thead {
  background-color: orange
}
</style>

<script>
import addBooks from '../views/addBooks'
import myBooks from '../views/myBooks'
import count from '../views/count'

export default {
    data() {
        return {
            books: []
        }
    },
    components: {
        addBooks: addBooks,
        myBooks: myBooks,
        count: count

    },
    // 挂载后
            mounted() {
                this.getBooks()
            },
            methods: {
                getBooks() {
                    this.$http.get('/getbooks').then(res => {
                        this.books = res.data
                    })
                },
                deletebook(id) {
                    this.$http.get('/deletebooks/' + id + '').then(res => {
                        var msg = res.data
                        if (msg === 'ok') {
                            this.getBooks()
                            // layer.msg('删除成功', { icon: 1 })
                        } else {
                            // layer.msg('删除失败', { icon: 2 })
                        }
                    })
                },
                getAddbook(id, name) {
                    var params = new URLSearchParams()
                    params.append('id', id)
                    params.append('name', name)
                    this.$http.post('/addbooks', params).then(res => {
                        var msg = res.data
                        if (msg === 'ok') {
                            this.getBooks()
                            // layer.msg('增加成功', { icon: 1 })
                        }
                    })
                },
                updatebook(id, name) {
                    var params = new URLSearchParams()
                    params.append('id', id)
                    params.append('name', name)
                    this.$http.post('/updatebooks', params).then(res => {
                        var msg = res.data
                        if (msg === 'ok') {
                            this.getBooks()
                            // layer.msg('修改成功', { icon: 1 })
                        } else {
                            // layer.msg('修改失败', { icon: 2 })
                        }
                    })
                }
            },
            computed: {
                counts: function () {
                    return this.books.length
                }
            }
}
</script>