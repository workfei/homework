<template>
    <div class="wy-player" @click="rotate">
                <header>
                    <div class="title">
                        <h3>XM PLAYER</h3>
                    </div>
                    <div class="search">
                        <input type="text" value="" autocomplete="on" v-model.trim="musicname" @keydown.enter="getMusic">
                        <img src="../assets/img/search.png" alt="" class="sear-icon" @click="getMusic">
                    </div>
                </header>
                <article>
                    <div class="left">
                        <ul>
                            <li v-for="val in musichouse" @click="musli(val.id)" :key="val.id">
                                <img src="../assets/img/icon.png" alt="">
                                <span>{{val.name}}</span>
                                <img src="../assets/img/MV.png" alt="" v-if="val.mvid != 0 ? true : false" @click.stop="getMv(val.mvid)">
                            </li>
                        </ul>
                    </div>
                    <div class="center">
                        <div class="cd">
                            <div class="mvbox" v-if="mvurl != null">
                                <video :src="mvurl" controls autoplay></video>
                            </div>
                            <div class="poster"><img :src="posterimg" alt=""></div>
                        </div>
                    </div>
                    <div class="right">
                        <h4>热门留言</h4>
                        <ul>
                            <li v-for="val in hotcomments" :key="val.id">
                                <img :src=val.user.avatarUrl alt="">
                                <span>{{val.user.nickname}}</span>
                                <p>{{val.content}}</p>
                            </li>
                        </ul>
                    </div>
                </article>
                <footer>
                    <audio :src="songurl" controls autoplay></audio>
                </footer>
            </div>
</template>

<style scoped>
@import '../assets/css/wyy.css';
</style>

<script>
export default {
    data() {
        return {
            musicname: '', // 绑定搜索的歌名
            musichouse: [], // 存储查询到的歌曲
            posterimg: '../assets/img/logo.png', // 歌曲海报
            hotcomments: [], // 歌曲评论
            songurl: '', // 歌曲链接
            repeatid: '', // 当前音乐的id号
            deg: 0, // 存储旋转角度
            timer: null, // 定义唱片旋转的定时器
            mvurl: null, // 歌曲mv地址
            vidstatus: null
        }
    },
    methods: {
                // 查询歌曲信息
                async getMusic() {
                    this.$http.get('https://autumnfish.cn/search?keywords=' + this.musicname).then(res => {
                    if (!res.data.msg) {
                        this.musichouse = res.data.result.songs
                    } else {
                        // layer.msg('查无此歌曲/歌星', { icon: 3 });
                    }
                    })
                },
                // 点击获取歌曲信息
                async musli(id) {
                    this.mvurl = null
                    /* 获取歌曲海报 */
                    this.$http.get('https://autumnfish.cn/song/detail?ids=' + id).then(res => {
                        this.posterimg = res.data.songs[0].al.picUrl
                    })
                    /* 获取歌曲评论 */
                    this.$http.get('https://autumnfish.cn/comment/hot?type=0&id=' + id).then(res => {
                        this.hotcomments = res.data.hotComments
                    })
                    /* 获取歌曲链接 */
                    this.$http.get('https://autumnfish.cn/song/url?id=' + id).then(res => {
                    if (this.repeatid !== id) {
                        this.deg = 0
                        this.vidstatus = '播放'
                        // layer.load(1);
                        // setTimeout(function () {
                        //     layer.closeAll('loading');
                        // }, 500)
                        this.songurl = res.data.data[0].url
                        this.repeatid = id
                    } else {
                        // layer.msg('请勿重复播放', { icon: 6 });
                    }
                    })
                },
                /* mv播放 */
                async getMv(id) {
                    this.vidstatus = '暂停'
                    /* mv地址获取 */
                    this.$http.get('https://autumnfish.cn/mv/url?id=' + id).then(res => {
                        this.mvurl = res.data.data.url
                    })
                },
                // DOM元素的动画效果
                rotate() {
                    var player = document.querySelector('footer audio')
                    setTimeout(() => {
                        if (player.paused) {
                            this.vidstatus = '暂停'
                        } else {
                            this.vidstatus = '播放'
                        }
                    }, 1000)
                }
            },
             watch: {
                vidstatus: function () {
                    if (this.vidstatus === '暂停') {
                        clearInterval(this.timer)
                    } else {
                        clearInterval(this.timer)
                        this.timer = setInterval(() => {
                            document.querySelector('.poster').style.transform = 'rotateZ(' + this.deg + 'deg)'
                            this.deg++
                        }, 30)
                    }
                }
            }
}
</script>