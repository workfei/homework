<template>
  <div>
    <h1>添加用户{{ $route.params.id }}</h1>
    <el-row>
      <el-button plain>朴素按钮</el-button>
      <el-button type="primary" plain>主要按钮</el-button>
      <el-button type="success" plain>成功按钮</el-button>
      <el-button type="info" plain>信息按钮</el-button>
      <el-button type="warning" plain>警告按钮</el-button>
      <el-button type="danger" plain>危险按钮</el-button>
    </el-row>
  </div>
</template>
<script>
export default {
    data () {
        return {
            msg: []
        }
    },
    mounted () {
    }
}
</script>