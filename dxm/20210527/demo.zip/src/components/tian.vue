<template>
  <div class='box'>
    <div class='logo'>
      <img src='../assets/img/wea_logo.png' alt='' />
    </div>
    <div class='search'>
      <input
        type='search'
        name=''
        id=''
        v-model.trim='city'
        placeholder='请输入需要查询的城市'
        class='sch'
        maxlength='10'
        @keydown.enter='getWeather'
        ref='cinp'
      />
      <input type='button' value='搜索' class='btn' @click='getWeather' />
    </div>
    <div class='hotcity'>
      <span @click='getCity("北京")'>北京</span>
      <span @click='getCity("上海")'>上海</span>
      <span @click='getCity("广州")'>广州</span>
      <span @click='getCity("深圳")'>深圳</span>
    </div>
    <ul class='weather'>
        <li v-for="val in citydata" :key="val.id">
            <h2>{{val.type}}</h2>
            <p>{{val.high}}~{{val.low}}</p>
            <span>{{val.date}}</span>
        </li>
    </ul>
    <div class='ganmao'>
      <p>{{ ganmao }}</p>
    </div>
  </div>
</template>

<style scoped>
@import '../assets/css/tian.css';
</style>

<script>
export default {
  data() {
    return {
      city: '邵阳',
      citydata: [],
      ganmao: '',
      result: null,
      status: 0
    }
  },
  methods: {
    async getWeather() {
      var reg = /^[^u4E00-u9FA5]{0,}$/g
      if (this.city === '') {
        // layer.msg('请输入内容', { icon: 3 });
        this.$refs.cinp.focus()
      } else if (reg.test(this.city) === false) {
        // layer.msg('城市名的格式不对哦', { icon: 0 })
        this.$refs.cinp.select()
      } else {
        this.$http.get('http://wthrcdn.etouch.cn/weather_mini?city=' + this.city).then(res => {
            this.status = res.data.status
            this.result = res.data.data
            if (this.status === 1000) {
                this.citydata = this.result.forecast
                this.ganmao = this.result.ganmao
            //   layer.load(1)
            //   setTimeout(() => {
            //     layer.closeAll('loading')
            //     this.citydata = result.data.data.forecast
            //     this.ganmao = result.data.data.ganmao
            //   }, 500)
            } else {
            //   layer.msg('查无此城市', { icon: 5 })
            }
        })
      }
    },
    getCity(cityname) {
        this.city = cityname
        this.getWeather()
    }
  },
  mounted() {
    this.getWeather()
  }
}
</script>