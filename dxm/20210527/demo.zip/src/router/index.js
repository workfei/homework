import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from '../views/Home.vue'
import adduser from '../components/adduser'
import userlist from '../components/userlist'
import tian from '../components/tian'
import wyy from '../components/wyy'
import books from '../components/books'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'login',
    component: () => import('../views/login.vue')
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/login.vue')
  },
  {
    path: '/main',
    name: 'Main',
    component: () => import('../views/Main.vue'),
    children: [
      {
        path: '/',
        name: 'userlist',
        component: userlist
      },
      {
        path: '/adduser/:id',
        name: 'adduser',
        component: adduser
      },
      {
        path: '/userlist',
        name: 'userlist',
        component: userlist
      },
      {
        path: '/tian',
        name: 'tian',
        component: tian
      },
      {
        path: '/wyy',
        name: 'wyy',
        component: wyy
      },
      {
        path: '/books',
        name: 'books',
        component: books
      }
    ]
  },
  {
    path: '/contact',
    name: 'Contact'
    // component: () => import('../views/Contact.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
