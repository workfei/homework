import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'

Vue.use(ElementUI)
Vue.config.productionTip = false
// 配置axios
const Axios = axios.create({
  // 请求接口
  baseURL: 'http://localhost:3000',
  timeout: 8000,
  headers: {
    'Content-type': 'application/x-www-form-urlencoded'
  }
})
// 请求拦截器
// Axios.interceptors.request.use(function (config) {
//   config.headers.mytoken = 'jwkyl'
//   return config
// }, function (err) {
//   console.log(err)
// })
// 响应拦截器
// Axios.interceptors.response.use(function (config) {
//   config.headers.mytoken = 'jwkyl'
//   return config
// }, function (err) {
//   console.log(err)
// })
// 将axios挂载到Vue的原型上
Vue.prototype.$http = Axios

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
