<template>
    <div>
        <p>图书总数：<span>{{counts}}</span></p>
    </div>
</template>

<script>
export default {
    props: ['counts']
}
</script>