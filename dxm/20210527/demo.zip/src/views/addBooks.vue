<template>
    <div class='book'>
                <label for=''>ID:</label>
                <input type='text' name='' id='' v-model.trim='id' ref='uid' :disabled='flag'>
                <label for=''>图书名称:</label>
                <input type='text' name='' id='' v-model.trim='name' ref='iname'>
                <button @click='handle(id,name)' :disabled='btnflag'>{{btnMsg}}</button>
            </div>
</template>

<script>
// var hub = new Vue()
export default {
    props: ['books'],
    data() {
        return {
            id: '',
                    name: '',
                    btnMsg: '提交',
                    flag: false,
                    btnflag: false,
                    btnflag2: false
        }
    },
    methods: {
                handle(id, name) {
                    if (this.flag) {
                        if (this.name === '') {
                            this.$refs.iname.focus()
                        } else {
                            this.$emit('update', id, name)
                            this.id = ''
                            this.name = ''
                            this.flag = false
                            this.btnMsg = '提交'
                        }
                    } else {
                        if (this.id === '') {
                            this.$refs.uid.focus()
                        } else if (this.name === '') {
                            this.$refs.iname.focus()
                        } else {
                            this.$emit('add', id, name)
                            this.id = ''
                            this.name = ''
                        }
                    }
                }
            },
            mounted() {
                // hub.$on('update', (id, name, flag) => {
                //     this.id = id
                //     this.name = name
                //     this.flag = flag
                //     this.btnMsg = '修改'
                // })
            },
            watch: {
                id: function () {
                    var flag = this.books.some(val => val.id === this.id)
                    if (!this.flag) {
                        if (flag) {
                            this.btnflag = true
                            this.btnflag2 = true
                        } else {
                            this.btnflag = false
                            this.btnflag2 = false
                        }
                    }
                },
                name: function () {
                    var flag = this.books.some(val => val.name === this.name)
                    if (!this.btnflag2) {
                        if (flag) {
                            this.btnflag = true
                        } else {
                            this.btnflag = false
                        }
                    }
                }
            }
}
</script>