<template>
  <table width="80%" height="80" border="1">
    <thead>
      <tr>
        <th>ID</th>
        <th>图书名称</th>
        <th>时间</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="val in books" :key="val.id">
        <td>{{ val.id }}</td>
        <td>{{ val.name }}</td>
        <td>{{ val.date }}</td>
        <td>
          <a href="" @click.prevent="send(val.id, val.name, flag)">修改</a>
          <a href="" @click.prevent="$emit('delete', val.id)">删除</a>
        </td>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  props: ['books'],
  data() {
    return {
      flag: true
    }
  }
}
</script>