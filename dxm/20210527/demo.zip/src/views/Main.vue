<template>
<div>
    <my-header></my-header>
    <div class="box">
        <div class="left">
            <ul>
                <li>
                    <router-link to="/adduser/1">添加用户</router-link>
                </li>
                <li>
                    <router-link to="/userlist">用户列表</router-link>
                </li>
                <li>
                    <router-link to="/tian">天知道</router-link>
                </li>
                <li>
                    <router-link to="/wyy">网易云音乐</router-link>
                </li>
                <li>
                    <router-link to="/books">图书管理</router-link>
                </li>
            </ul>
        </div>
        <div class="right">
            <router-view></router-view>
        </div>
    </div>
    <my-footer></my-footer>
</div>
</template>

<style scoped>
@import "../assets/css/common.css";
.box{
    height: 550px;
}
.left{
    width: 20%;
    height: 550px;
    background-color: #999;
    float: left;
}
.right{
    width: 80%;
    height: 550px;
    float: left;
}
.left li{
    height: 50px;
    background-color: skyblue;
    line-height: 50px;
    list-style: none;
    border-bottom: 1px solid #fff;
}
</style>

<script>
import myHeader from './Header'
import myFooter from './Footer'
export default {
    data() {
        return {}
    },
    components: {
        myHeader: myHeader,
        myFooter: myFooter
    }
}
</script>