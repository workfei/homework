<template>
    <header>六班管理系统</header>
</template>
<style scoped>
header {
    height: 50px;
    background-color: #999;
    line-height: 50px;
    text-align: center;
    font-size: 25px;
    color: #fff;
}
</style>
