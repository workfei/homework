<template>
    <h1>您好</h1>
</template>
<style>
    h1 {
        color: red;
    }
</style>
