<template>
    <footer>版权归六班所有</footer>
</template>
<style scoped>
footer {
    height: 50px;
    background-color: #999;
    line-height: 50px;
    text-align: center;
    font-size: 25px;
    color: #fff;
}
</style>
