module.exports = {
    devServer:{
        port:8088,
        open:true
    }
}